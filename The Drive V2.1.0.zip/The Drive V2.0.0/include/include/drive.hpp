#include "main.h"

//driver control functions
void setDriveMotors();
void setDrive(int left,int right);
void setIntake(int powerr);
void setWinch(int degrees);