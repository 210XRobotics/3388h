#include "main.h"

void setDrive(int left, int right){
    driveLeftBack = left;
    driveLeftFront = left;
    driveRightBack = right;
    driveRightFront = right; 
}

void setIntake(int powerr){
    intakeMotor1 = powerr;
    intakeMotor2 = -powerr;
}

void setWinch(int degrees){
    // Adjust pull Sdistance
    winchMotor.move_relative(degrees, 127);
    pros::delay(500);
}

void setDriveMotors(){ 

   // int leftJoystick = controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_Y);
   // int rightJoystick = controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
    int turn = -1 *  controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
    int power = -1*controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_X);

    if( power< 0){
      power = -1* (power*power)/85;   
    }
    else{
        power =  (power*power)/185;
    }
    
    int Left = power + turn;
    int Right = power - turn;
    if(abs(Left) <2){
        Left =0;
    }   
    if(abs(Right) < 2){
        Right =0;
    }   

    setDrive(Left,Right);
}

